Run on IntelliJ

Prerequisites:
jdk 22.0.01

Features:
Crypto Library is being used internally by Java 8
ECB done by default internally by Java CYPHER_ALGORITHM. 
No need to externally block split the input plain text.
Key Padding done to 16, 24, 32 bytes depending on user key input using adjustKeyLenght().
